Extensiones de ayuda:
-Error Lens
-Console Ninja
-Prettier

`document.write => para mostrar en pantalla lo expresado entre los parentesis`
`document.write("Bienvenidos a DEV.F")`
